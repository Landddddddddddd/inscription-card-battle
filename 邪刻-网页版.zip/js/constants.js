// Shared card & rule definitions. Pure data — safe to import in both Node and the browser.

export const CONFIG = {
  LANES: 4,
  HAND_START: 4,
  DRAW_PER_TURN: 1,
  HAND_LIMIT: 10,
  WIN_SCALE: 6,          // unblocked attack points needed to tilt the scale to a win
  FIRST_HANDICAP: 1,     // 先手方（房主/你）开局天平 -1，作为先手优势的平衡修正
  ENERGY_CAP: 5,         // energy faction ramp cap: 1,2,3,4,5 then stays at 5
  ENERGY_RAMP_EVERY: 2,   // 旧整数取模爬升（每 N 个己方回合 +1）；仅当未设 ENERGY_RAMP_FRAC 时生效
  // 能量爬升 = 小数滴流：每回合累加本值，满 1 才 +1 能量上限（与骸骨 BONE_PER_TURN 同源）。
  // 0.5 与旧整数行为（ENERGY_RAMP_EVERY=2 → 0,1,1,2,2,3,3,4,4,5）完全等价。
  // 之所以改成小数：整数取模只能整档跳——每 2 回合 +1 能量仅 44%，每回合 +1 则飙到 83%，
  // 中间无档可停，无法把六阵营 spread 拉回 ≤10。
  // 实测响应：0.50→44.2% / 0.60→44.3% / 0.65→45.4% /[断崖] / 0.70→57.3% / 0.75→59.5% / 1.00→83%。
  // 断崖成因是「第 3 回合能否凑满 2 能量」——提前一回合拍出 2 费 3/3 双重打击（猞猁/螳螂）
  // 就会滚雪球。故取断崖前最高可用档 0.65（配合 BONE_PER_TURN=0.85，六阵营 spread ≈8.4pt）。
  ENERGY_RAMP_FRAC: 0.65,
  BONE_CAP_MAX: 12,
  BONE_PER_TURN: 0.85,    // 骸骨兜底滴流（小数）：每回合累加，满 1 才 +1 骸骨。与死亡经济叠加后约 50%
                          // 胜率，仅防前期断档不叠加成洪流。0.75→0.85（+0.1）用于补回骸骨因每日新增
                          // 卡池稀释而下滑的胜率（45.3%→46.6%），六阵营 spread 降到 ≈8.4pt。
  BONE_DEATH_GAIN: 1,     // 骸骨阵营：己方单位「以任何方式死亡」（含 0 费易碎生物攻击后碎裂）每只 +1 骸骨
  BLOOD_PER_TURN: 0,      // 每回合无偿血肉 = 0（用户硬约束：血肉阵营不靠无偿发放，完全靠献祭已召唤单位来获得血肉）。pool 恒为 0，所有 blood 卡费用都由场上单位 bloodValue 支付。平衡由卡牌数值承担。
  // 时砂阵营：pl.seconds 即本回合「出牌时间」= 时砂专属的回合预算（真实倒计时，见 main.js 计时器）。
  // 它与全局菜单 turnTime 解耦——若直接等于菜单 10/20/30/60，时砂强弱会随设置八倍摆动（10s 废掉、
  // 60s 碾压），无法平衡。时砂的「资源」就是出牌倒计时本身（时间即资源、不可透支、不跨回合累计）。
  // 关键平衡：预算随己方回合数小幅爬升（BASE + 己方回合数×STEP，封顶 CAP），开局只有 BASE 秒、
  // 只够打砂砾级弱牌，从而与「能量阵营能量从 1 爬升」对齐——否则时砂每回合必有真打手戳空列推
  // 天平，「分数差 5 分」模式下 3 回合速胜、结构性碾压。爬升是「每回合归零重计的计划值」而非累计，
  // 仍满足用户「不跨回合累计」硬约束（时砂越战越从容，但每回合从 BASE 重新流）。
  SAND_BUDGET_BASE: 2,   // 时砂：第 1 个己方回合的「出牌时间」预算（秒）
  SAND_BUDGET_STEP: 1,   // 时砂：每次爬升 +1 秒
  SAND_BUDGET_CAP: 5,    // 时砂：预算封顶（秒）；与最高卡费(5秒)对齐，保证全部时砂牌都可打出；菜单 turnTime 仍决定其它阵营思考时限
  // 时砂预算爬升同样用「小数滴流」：预算 = BASE + (己方回合数-1)×SAND_RAMP_FRAC，向下取整、封顶 CAP。
  // 实测秒数是「悬崖型」杠杆：每回合 +1（2,3,4,5,5…）时砂约 55%，每 2 回合 +1（2,3,3,4,4,5…）
  // 直接崩到 17.7%——因为本作强正反馈（落后一张牌→被吃→更落后）且秒数只能整秒跳。
  // 保留小数旋钮以便连续细调（1.0 = 每回合 +1；0.8 → 2,2,3,4,4,5…）。
  SAND_RAMP_FRAC: 1.0,
  // 军威阵营：士气由「造成伤害」累积（交战打敌方单位给全额 + 尖刺反伤；天平直击给折减），
  // 跨回合累计、不重置（与血肉「不攒」相反，这是军威特色：前期攒后期爆发）。
  // 天平（取胜动作）伤害折减产士气——否则攻击天平既推胜利又滚经济会双重碾压（初版满额 88% 失衡）。
  // MORALE_CAP 防存量无限膨胀；MORALE_GAIN_PER_TURN_CAP 防交战单回合无上限雪球。开局 0、无无偿发放。
  MORALE_CAP: 10,
  MORALE_GAIN_PER_TURN_CAP: 6,
  // 天平（直击空列/飞行越界）伤害产士气的「折减系数」（分数累积，避免整数 floor 吞小伤害）：
  // 交战（打敌方单位）伤害给全额（1 伤=1 士气，忠实「打在对方卡牌上」），天平伤害只给本系数倍
  // （忠实「成为得分也攒士气」的意味但压到可平衡）。初版天平给满额导致 88% 失衡（攻击取胜动作
  // 既推胜利又滚经济双重碾压），故天平士气须是「稳定细水」而非爆发源。
  // 最终值 0.22 由平衡仿真扫参确定（PER=500：六阵营 spread 5.5pt，各阵营 48–54%）。
  MORALE_SCALE_RATE: 0.22,
  DECK_MIN: 5,           // deck builder constraints（0 费卡下限：卡组最少 5 张）
  DECK_MAX: 30,
  ZERO_COST_MAX: 15,     // 单张 0 费卡在卡组中的最多重复数（原上限 2，现放宽到 15）
};

// ============================================================================
// CUSTOM MATCH RULES (自定义房间规则)
// A per-game "rules" object travels inside the game state, so both LAN peers
// and the renderer always agree on lanes / win target / draw count / deck scope.
// ============================================================================
export const RULE_OPTIONS = {
  lanes:       [3, 4, 5, 6, 7],            // board size (columns per side)
  winMode:     ['difference', 'absolute'],// 胜利方式：分数差 / 累计分数
  drawPerTurn: [1, 2, 3],                  // cards drawn at the start of each turn
  deckScope:   ['all', 'blood', 'bone', 'energy', 'mox', 'sand', 'morale'], // deck restriction
};
// 胜利目标可自定义的上限（防止异常数值）。
export const WIN_SCALE_CAP = 200;
// 不同胜利方式提供不同的预设目标分；累计分数（absolute）模式允许更高的自定义数值。
export function winScaleOptions(mode) {
  return mode === 'absolute'
    ? [10, 15, 20, 30, 40, 50, 75, 100]
    : [3, 4, 5, 6, 8, 10, 12];
}
export const DEFAULT_RULES = { lanes: 4, winMode: 'difference', winScale: 5, drawPerTurn: 1, deckScope: 'all' };

// 胜利方式的默认目标分（可在规则面板自定义）。
export function defaultWinScaleFor(mode) { return mode === 'absolute' ? 10 : 5; }
export function winModeName(m) { return m === 'absolute' ? '累计分数' : '分数差'; }
export function winModeDesc(m) {
  return m === 'absolute'
    ? '双方各自累计「未阻挡攻击」分数，先达到目标分者获胜。'
    : '比拼双方分数差，先拉开到目标分差者获胜（拉锯更激烈，适合快节奏对局）。';
}

export const SCOPE_NAMES = { all: '不限阵营', blood: '仅血肉', bone: '仅骸骨', energy: '仅能量', mox: '仅魔石' };

// ============================================================================
// RANKED LADDER (排位赛)
// 6 阶（一阶最低 → 六阶最高），每阶分 下/中/上 三个小阶，共 18 个段位。
// 最高段位 = 六阶·上。胜 +晋级分，负 −晋级分；满 DIV_PROMOTE 升上一小阶、
// 归零则降下一小阶。仅限 PVP（同屏双人对战）。
// ============================================================================
export const RANK = {
  TIERS: 6,
  DIVS: 3,                       // 每阶 3 个小阶：下(0) / 中(1) / 上(2)
  DIVISIONS: ['下', '中', '上'],
  TIER_NAMES: ['', '一阶', '二阶', '三阶', '四阶', '五阶', '六阶'], // 索引 1..6
  TIER_COLORS: ['', '#9aa0a8', '#cd7f32', '#c0c0c0', '#e7b53a', '#4fd1c5', '#5aa6ff'],
  POINTS_WIN: 30,               // 每胜一场 +30 晋级分
  POINTS_LOSE: 30,              // 每负一场 −30 晋级分
  DIV_PROMOTE: 100,             // 小阶内满 100 分即晋级
};
export function rankLabel(rank) {
  const tier = Math.min(RANK.TIERS, Math.max(1, (rank && rank.tier) || 1));
  const div = Math.min(RANK.DIVS - 1, Math.max(0, (rank && rank.div) || 0));
  return `${RANK.TIER_NAMES[tier]}·${RANK.DIVISIONS[div]}`;
}
export function rankColor(tier) {
  tier = Math.min(RANK.TIERS, Math.max(1, tier || 1));
  return RANK.TIER_COLORS[tier];
}
export function rankIndex(rank) {
  const tier = Math.min(RANK.TIERS, Math.max(1, (rank && rank.tier) || 1));
  const div = Math.min(RANK.DIVS - 1, Math.max(0, (rank && rank.div) || 0));
  return (tier - 1) * RANK.DIVS + div; // 0 = 一阶·下 … 17 = 六阶·上
}
export function rankFromIndex(i) {
  i = Math.min(RANK.TIERS * RANK.DIVS - 1, Math.max(0, i | 0));
  return { tier: Math.floor(i / RANK.DIVS) + 1, div: i % RANK.DIVS, points: 0 };
}
export function isTopRank(rank) {
  return (rank && rank.tier >= RANK.TIERS && rank.div >= RANK.DIVS - 1);
}

// Clamp/normalize an arbitrary rules object to legal values (never throws).
export function normalizeRules(r) {
  const src = r && typeof r === 'object' ? r : {};
  const pick = (key, fallback) => {
    const v = Number(src[key]);
    return RULE_OPTIONS[key].includes(v) ? v : fallback;
  };
  const winMode = RULE_OPTIONS.winMode.includes(src.winMode) ? src.winMode : DEFAULT_RULES.winMode;
  // 胜利目标：允许 1~WIN_SCALE_CAP 之间的任意整数自定义（累计分数模式可设很高）。
  const wsRaw = Number(src.winScale);
  const winScale = (Number.isFinite(wsRaw) && Number.isInteger(wsRaw) && wsRaw >= 1 && wsRaw <= WIN_SCALE_CAP)
    ? wsRaw : defaultWinScaleFor(winMode);
  return {
    lanes: pick('lanes', DEFAULT_RULES.lanes),
    winMode,
    winScale,
    drawPerTurn: pick('drawPerTurn', DEFAULT_RULES.drawPerTurn),
    deckScope: RULE_OPTIONS.deckScope.includes(src.deckScope) ? src.deckScope : DEFAULT_RULES.deckScope,
  };
}

// Which faction a card belongs to, derived from its cost type.
export function factionOfCard(id) {
  const c = CARDS[id];
  if (!c) return null;
  return c.costType === 'gem' ? 'mox' : c.costType; // blood / bone / energy / mox
}

// 是否为「有费卡」：需要付出资源才能召唤，卡组中每张最多 1 份。
//   - 数值费用卡：cost > 0（血肉/骸骨/能量）
//   - 魔石法术卡：costType==='gem' 且需要特定宝石（gemCost 非空）——召唤受魔石限制，视为有费卡
// 真正的 0 费免费卡（cost===0 且无宝石要求，如魔石生物）才允许重复（上限 ZERO_COST_MAX）。
export function isCostedCard(id) {
  const c = CARDS[id];
  if (!c) return false;
  if (c.cost > 0) return true;
  if (c.costType === 'gem') return (c.gemCost || []).length > 0; // 需要特定魔石才能召唤
  return false;
}

// Does every card in `deck` satisfy the room's deck scope?
export function deckMatchesScope(deck, scope) {
  if (!scope || scope === 'all') return true;
  return (deck || []).every((id) => factionOfCard(id) === scope);
}

// Human-readable one-line summary, e.g. "场地5列 · 胜利·分数差5分 · 抽2张/轮 · 仅骸骨".
export function rulesSummary(r) {
  const rules = normalizeRules(r);
  const parts = [`场地${rules.lanes}列`, `胜利·${winModeName(rules.winMode)}${rules.winScale}分`, `抽${rules.drawPerTurn}张/轮`];
  if (rules.deckScope !== 'all') parts.push(SCOPE_NAMES[rules.deckScope]);
  return parts.join(' · ');
}

// Gem (魔石) colors for the Mox faction. A Mox creature on the board provides
// its color; Wizard cards require the matching gem(s) *present on the board*
// to be summoned (gems are a board-presence resource, not consumed on cast).
export const GEMS = {
  orange: { name: '橙', color: '#e67e22' },
  green:  { name: '绿', color: '#27ae60' },
  blue:   { name: '蓝', color: '#2980b9' },
};

// Sigil (ability) metadata. Codes used by CARDS below.
export const SIGILS = {
  airborne:      { name: '飞行', desc: '可越过地面阻挡直接攻击天平；仅能被飞行单位阻挡。' },
  double_strike:{ name: '连击', desc: '每次攻击造成两次伤害（攻击天平时也翻倍）。' },
  poison_touch:  { name: '毒触', desc: '攻击时额外造成 1 点伤害。' },
  sharp_quills:  { name: '尖刺', desc: '被攻击时，攻击它的单位受到 1 点伤害。' },
  undying:       { name: '不死', desc: '首次死亡时返回手牌，而非进入弃牌堆。' },
  loose_tail:    { name: '断尾', desc: '死亡时，随机获得一只松鼠到手牌。' },
  pack:          { name: '头狼', desc: '使相邻友方单位的攻击力 +1。' },
  burrower:      { name: '掘洞', desc: '可在己方空列之间移动（预留特性）。' },
  brittle:       { name: '易碎', desc: '攻击一次后立即死亡（碎裂）。' },
  death_touch:   { name: '致死', desc: '造成的任何伤害都会直接杀死目标（无视剩余生命）。' },
  armored:       { name: '厚甲', desc: '受到的伤害 −1（最低为 0）。' },
  frenzy:        { name: '狂热', desc: '每回合开始攻击力 +1（封顶 6）。越拖越凶。' },
  regen:         { name: '回复', desc: '每回合开始恢复 1 点生命（不超过上限）。持久消耗战核心。' },
};

// costType: 'blood' | 'bone' | 'energy' | 'gem'
//   - blood  阵营：献祭生物换血肉，花血肉召唤
//   - bone   阵营：生物死亡积累骸骨，花骸骨召唤
//   - energy 阵营：每回合稳定回能量
//   - mox    阵营：魔石体系。场上每有一只「魔石生物」即提供一种颜色的魔石（橙/绿/蓝），
//                  法术(Wizard)卡 costType='gem'，需场上存在对应颜色的魔石才能召唤
//                  （魔石生物一旦死亡，就失去该颜色的魔石）。魔石生物本身免费(0费)。
// bloodValue: how much blood a sacrifice of this creature yields (universal sacrifice currency)
export const CARDS = {
  // ===================== BLOOD（血肉）=====================
  // 0 费真·免费卡（零投入即可打出）：不应具备攻击，定位为铺场/祭品炮灰。
  // 注意：骸骨阵营的 0 费卡（bone_pup）豁免——其"费用"由死亡产骸骨偿还；
  // 魔石法术卡虽 cost:0，但需场上对应魔石才能召唤，并非免费，亦不受影响。
  squirrel:    { name: '松鼠',   atk: 0, hp: 1, cost: 0, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#8a5a2b', glyph: '鼠' },
  stoat:       { name: '白鼬',   atk: 2, hp: 1, cost: 1, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#d9d2c5', glyph: '鼬' },
  raven:       { name: '乌鸦',   atk: 1, hp: 1, cost: 1, costType: 'blood', sigils: ['airborne'],       bloodValue: 2, color: '#2b2b3a', glyph: '鸦' },
  mole:        { name: '鼹鼠',   atk: 1, hp: 1, cost: 1, costType: 'blood', sigils: ['undying'],        bloodValue: 2, color: '#5b4636', glyph: '鼹' },
  beaver:      { name: '河狸',   atk: 2, hp: 1, cost: 1, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#6b4f2a', glyph: '狸' },
  adder:       { name: '蝰蛇',   atk: 1, hp: 2, cost: 1, costType: 'blood', sigils: ['poison_touch'],  bloodValue: 2, color: '#3b6b3b', glyph: '蛇' },
  raccoon:     { name: '浣熊',   atk: 2, hp: 1, cost: 1, costType: 'blood', sigils: ['loose_tail'],    bloodValue: 2, color: '#7a6a55', glyph: '浣' },
  opossum:     { name: '负鼠',   atk: 2, hp: 2, cost: 2, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#7a6a55', glyph: '负' },
  wolf:        { name: '狼',     atk: 2, hp: 2, cost: 2, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#6e6e6e', glyph: '狼' },
  bullfrog:    { name: '牛蛙',   atk: 3, hp: 2, cost: 2, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#4a7a3a', glyph: '蛙' },
  vulture:     { name: '秃鹫',   atk: 3, hp: 1, cost: 2, costType: 'blood', sigils: ['airborne'],       bloodValue: 2, color: '#4a3a2a', glyph: '鹫' },
  cougar:      { name: '美洲狮', atk: 2, hp: 2, cost: 3, costType: 'blood', sigils: ['double_strike'],  bloodValue: 2, color: '#9a8a6a', glyph: '狮' },
  dire_wolf:   { name: '恐狼',   atk: 3, hp: 2, cost: 3, costType: 'blood', sigils: ['pack'],           bloodValue: 2, color: '#4a4a55', glyph: '恐' },
  hound:       { name: '猎犬',   atk: 3, hp: 3, cost: 3, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#8a6a3a', glyph: '犬' },
  skunk:       { name: '臭鼬',   atk: 1, hp: 2, cost: 1, costType: 'blood', sigils: ['brittle'],        bloodValue: 2, color: '#2b2b2b', glyph: '臭' },
  great_white: { name: '大白鲨', atk: 3, hp: 2, cost: 3, costType: 'blood', sigils: ['sharp_quills'],   bloodValue: 2, color: '#c8d6e0', glyph: '鲨' },
  warthog:     { name: '疣猪',   atk: 3, hp: 2, cost: 3, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#9a7a5a', glyph: '猪' },
  bear:        { name: '巨熊',   atk: 4, hp: 3, cost: 4, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#5a4636', glyph: '熊' },
  wolf_cub:    { name: '狼崽',   atk: 2, hp: 1, cost: 1, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#8a8a8a', glyph: '崽' },

  // 新增：印记演示卡（通用级，便于快速试玩）
  viper_king:  { name: '蝰王',   atk: 2, hp: 2, cost: 3, costType: 'blood', sigils: ['death_touch'],     bloodValue: 2, color: '#5a2a2a', glyph: '蝰' },

  // 新增普通卡（丰富卡池，配合"有费卡不可重复"规则提供更多可选单位）
  field_mouse: { name: '田鼠', atk: 2, hp: 1, cost: 1, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#9a8a6a', glyph: '田' },
  toad:        { name: '蟾蜍', atk: 2, hp: 2, cost: 1, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#4a7a3a', glyph: '蟾' },
  shrew:       { name: '鼩鼱', atk: 1, hp: 1, cost: 1, costType: 'blood', sigils: ['undying'],        bloodValue: 2, color: '#7a6a55', glyph: '鼩' },
  hawk:        { name: '苍鹰', atk: 1, hp: 2, cost: 1, costType: 'blood', sigils: ['airborne'],       bloodValue: 2, color: '#5a6a7a', glyph: '鹰' },
  ferret:      { name: '雪貂', atk: 2, hp: 2, cost: 2, costType: 'blood', sigils: [],                 bloodValue: 2, color: '#b8a890', glyph: '貂' },

  // 新增：印记演示卡（狂热 / 回复）
  warg:        { name: '战狼',   atk: 2, hp: 2, cost: 2, costType: 'blood', sigils: ['frenzy'],        bloodValue: 2, color: '#9a5a3a', glyph: '战' },
  rat_king:    { name: '鼠王',   atk: 1, hp: 3, cost: 2, costType: 'blood', sigils: ['regen'],         bloodValue: 2, color: '#8a7a6a', glyph: '王' },
  berserker:   { name: '狂战士', atk: 3, hp: 2, cost: 3, costType: 'blood', sigils: ['frenzy','double_strike'], bloodValue: 2, color: '#b5241f', glyph: '狂' },

  // [daily 2026-08-09] 重甲獾
  armored_badger: { name: '重甲獾', atk: 2, hp: 1, cost: 2, costType: 'blood', sigils: ['armored'],        bloodValue: 2, color: '#6b5a4a', glyph: '獾' },

  // [daily 2026-08-12] 刺猬
  hedgehog:    { name: '刺猬', atk: 2, hp: 2, cost: 2, costType: 'blood', sigils: ['sharp_quills'],  bloodValue: 2, color: '#7a5a3a', glyph: '猬' },

  // [daily 2026-08-14] 豪猪
  porcupine:   { name: '豪猪', atk: 2, hp: 1, cost: 1, costType: 'blood', sigils: ['sharp_quills'],  bloodValue: 2, color: '#7a5a3a', glyph: '豪' },

  // [daily 2026-08-15] 水獭
  otter:       { name: '水獭', atk: 2, hp: 2, cost: 2, costType: 'blood', sigils: ['undying'],        bloodValue: 2, color: '#6b4f3a', glyph: '獭' },

  // [daily 2026-09-05] 火蝾螈
  fire_salamander: { name: '火蝾螈', atk: 1, hp: 1, cost: 1, costType: 'blood', sigils: ['regen'],         bloodValue: 2, color: '#c84a2a', glyph: '蝾' },

  // [daily 2026-08-31] 穿山甲（补跑；血肉首张「厚甲+尖刺」双防印记：低攻铁壁，磨血反伤）
  pangolin: { name: '穿山甲', atk: 1, hp: 2, cost: 2, costType: 'blood', sigils: ['armored','sharp_quills'], bloodValue: 2, color: '#8a7a5a', glyph: '鳞' },

  // [daily 2026-09-01] 巨鳄（补跑；4 费素白大怪，贴线 4/4 对齐装甲野牛）
  giant_croc: { name: '巨鳄', atk: 4, hp: 4, cost: 4, costType: 'blood', sigils: [], bloodValue: 2, color: '#5a7a5a', glyph: '鳄' },

  // [daily 2026-09-03] 灰獴（补跑；1 费毒触小猎手，1/1 略弱于蝰蛇的 1/2）
  mongoose: { name: '灰獴', atk: 1, hp: 1, cost: 1, costType: 'blood', sigils: ['poison_touch'], bloodValue: 2, color: '#a89a6a', glyph: '獴' },

  // [daily 2026-09-04] 鸢（补跑；2 费飞行 2/1，介于秃鹫与苍鹰之间）
  kite: { name: '鸢', atk: 2, hp: 1, cost: 2, costType: 'blood', sigils: ['airborne'], bloodValue: 2, color: '#7a6a5a', glyph: '鸢' },

  // ===================== BONE（骸骨 · 亡灵墓地主题）=====================
  // 骸骨阵营的 0 费起手牌：免费铺场充当炮灰，死亡后即可积累骸骨（骸骨只从生物死亡获得）。
  bone_pup:    { name: '枯骨幼犬', atk: 1, hp: 1, cost: 0, costType: 'bone', sigils: ['brittle'],        bloodValue: 1, color: '#cfcabc', glyph: '骨' },
  rat:         { name: '瘟疫鼠',   atk: 1, hp: 1, cost: 1, costType: 'bone', sigils: [],                 bloodValue: 1, color: '#9a8a7a', glyph: '鼠' },
  cat:         { name: '墓园妖猫', atk: 1, hp: 1, cost: 1, costType: 'bone', sigils: [],                 bloodValue: 1, color: '#c9a96a', glyph: '猫' },
  spider:      { name: '墓穴蛛',   atk: 1, hp: 1, cost: 1, costType: 'bone', sigils: [],    bloodValue: 1, color: '#4a3a4a', glyph: '蜘' },
  bat:         { name: '骨翼蝠',   atk: 1, hp: 1, cost: 1, costType: 'bone', sigils: ['airborne'],       bloodValue: 1, color: '#3a2b3a', glyph: '蝠' },
  skeleton:    { name: '骷髅武士', atk: 2, hp: 1, cost: 2, costType: 'bone', sigils: [],                 bloodValue: 1, color: '#d8d8d0', glyph: '骷' },
  corpse:      { name: '腐尸',     atk: 1, hp: 3, cost: 2, costType: 'bone', sigils: [],                 bloodValue: 1, color: '#6a7a5a', glyph: '尸' },
  crab:        { name: '尸壳蟹',   atk: 1, hp: 2, cost: 2, costType: 'bone', sigils: ['sharp_quills'],  bloodValue: 1, color: '#c06a4a', glyph: '蟹' },
  scorpion:    { name: '毒骨蝎',   atk: 2, hp: 1, cost: 2, costType: 'bone', sigils: ['poison_touch'],  bloodValue: 1, color: '#a06a2a', glyph: '蝎' },
  zombie:      { name: '还魂僵尸', atk: 1, hp: 1, cost: 2, costType: 'bone', sigils: ['undying'],        bloodValue: 1, color: '#7a8a6a', glyph: '尸' },
  black_widow: { name: '幽冥寡妇', atk: 1, hp: 2, cost: 3, costType: 'bone', sigils: ['poison_touch'],  bloodValue: 1, color: '#2b1b2b', glyph: '蛛' },
  turtle:      { name: '朽甲龟',   atk: 1, hp: 4, cost: 3, costType: 'bone', sigils: [],                 bloodValue: 1, color: '#4a7a6a', glyph: '龟' },
  bone_hound:  { name: '骸骨猎犬', atk: 2, hp: 2, cost: 3, costType: 'bone', sigils: ['pack'],           bloodValue: 1, color: '#cfcabc', glyph: '骸' },
  geck:        { name: '墓行蜥',   atk: 2, hp: 2, cost: 4, costType: 'bone', sigils: [],                 bloodValue: 1, color: '#5a8a4a', glyph: '蜥' },

  // 新增普通卡
  lizard:      { name: '枯骨蜥', atk: 1, hp: 1, cost: 1, costType: 'bone', sigils: [],                 bloodValue: 1, color: '#7a8a5a', glyph: '蜥' },
  snail:       { name: '墓螺',   atk: 1, hp: 2, cost: 1, costType: 'bone', sigils: [],                 bloodValue: 1, color: '#9a8a7a', glyph: '螺' },
  moth:        { name: '尸蛾',   atk: 1, hp: 1, cost: 1, costType: 'bone', sigils: ['airborne'],       bloodValue: 1, color: '#6a5a6a', glyph: '蛾' },
  beetle:      { name: '甲虫',   atk: 1, hp: 2, cost: 1, costType: 'bone', sigils: [],                 bloodValue: 1, color: '#5a6a3a', glyph: '甲' },
  bonesnake:   { name: '骨蛇',   atk: 2, hp: 1, cost: 2, costType: 'bone', sigils: [],                 bloodValue: 1, color: '#8a9a7a', glyph: '蛇' },

  // 新增：印记演示卡（通用级）
  bone_warden: { name: '白骨守卫', atk: 2, hp: 4, cost: 3, costType: 'bone', sigils: ['armored'],        bloodValue: 1, color: '#d8d8d0', glyph: '卫' },

  // [daily 2026-08-09] 墓苔尸
  grave_moss:  { name: '墓苔尸',   atk: 1, hp: 3, cost: 2, costType: 'bone', sigils: ['regen'],          bloodValue: 1, color: '#6a8a5a', glyph: '苔' },

  // [daily 2026-08-12] 冢卫
  tomb_guard: { name: '冢卫',     atk: 1, hp: 3, cost: 2, costType: 'bone', sigils: ['armored'],        bloodValue: 1, color: '#9aa0a8', glyph: '冢' },

  // [daily 2026-08-14] 骨弓手
  bone_archer: { name: '骨弓手', atk: 1, hp: 2, cost: 2, costType: 'bone', sigils: ['airborne'],          bloodValue: 1, color: '#cfcabc', glyph: '弓' },

  // [daily 2026-08-30] 噬魂骨（骸骨阵营首张「致死」印记卡：任何伤害直接斩杀，脆身换血）
  soul_bone:  { name: '噬魂骨', atk: 2, hp: 2, cost: 3, costType: 'bone', sigils: ['death_touch'],         bloodValue: 1, color: '#cfcabc', glyph: '噬' },

  // [daily 2026-09-05] 哀号幽魂
  wailing_spirit: { name: '哀号幽魂', atk: 1, hp: 1, cost: 2, costType: 'bone', sigils: ['double_strike'],    bloodValue: 1, color: '#b8c0d8', glyph: '魂' },

  // [daily 2026-08-31] 食尸鬼（补跑；3 费素白 2/4，墓行军中坚）
  ghoul: { name: '食尸鬼', atk: 2, hp: 4, cost: 3, costType: 'bone', sigils: [], bloodValue: 1, color: '#6a7a6a', glyph: '煞' },

  // [daily 2026-09-02] 掘墓人（补跑；骸骨首张「断尾」：死亡送松鼠=续炮灰+骸骨经济）
  gravedigger: { name: '掘墓人', atk: 2, hp: 2, cost: 3, costType: 'bone', sigils: ['loose_tail'], bloodValue: 1, color: '#7a7a5a', glyph: '掘' },

  // [daily 2026-09-03] 食腐兽（补跑；骸骨首张「狂热」：1 攻起步逐回合滚大，1/3 撑到成长期）
  carrion_beast: { name: '食腐兽', atk: 1, hp: 3, cost: 2, costType: 'bone', sigils: ['frenzy'], bloodValue: 1, color: '#6a7a5a', glyph: '腐' },

  // [daily 2026-09-04] 恐惧骑士（补跑；4 费致死重骑，2/3 比 3 费噬魂骨多 1 血）
  dread_knight: { name: '恐惧骑士', atk: 2, hp: 3, cost: 4, costType: 'bone', sigils: ['death_touch'], bloodValue: 1, color: '#4a3a5a', glyph: '怖' },

  // ===================== ENERGY（能量 · 机械科技主题）=====================
  black_cat:   { name: '电池机偶', atk: 0, hp: 1, cost: 0, costType: 'energy', sigils: [],               bloodValue: 1, color: '#2b3b4b', glyph: '电' },
  magpie:      { name: '磁窃鸟',   atk: 2, hp: 1, cost: 1, costType: 'energy', sigils: [],               bloodValue: 1, color: '#3a3a4a', glyph: '磁' },
  fennec:      { name: '电路狐',   atk: 2, hp: 1, cost: 1, costType: 'energy', sigils: [],               bloodValue: 1, color: '#4a6a8a', glyph: '狐' },
  peacock:     { name: '雷达孔雀', atk: 1, hp: 3, cost: 1, costType: 'energy', sigils: [],               bloodValue: 1, color: '#2a6a9a', glyph: '雷' },
  lynx:        { name: '脉冲猞猁', atk: 3, hp: 3, cost: 2, costType: 'energy', sigils: ['double_strike'],bloodValue: 1, color: '#5a7a9a', glyph: '脉' },
  mantis:      { name: '机械螳螂', atk: 3, hp: 3, cost: 2, costType: 'energy', sigils: ['double_strike'],bloodValue: 1, color: '#4a8a7a', glyph: '械' },
  falcon:      { name: '喷射隼',   atk: 3, hp: 1, cost: 2, costType: 'energy', sigils: ['airborne'],       bloodValue: 1, color: '#5a6a8a', glyph: '隼' },
  ram:         { name: '液压撞羊', atk: 3, hp: 3, cost: 2, costType: 'energy', sigils: [],               bloodValue: 1, color: '#7a8a9a', glyph: '撞' },
  grey_jaguar: { name: '钢甲豹',   atk: 3, hp: 2, cost: 2, costType: 'energy', sigils: [],               bloodValue: 1, color: '#6a7a86', glyph: '钢' },
  eagle:       { name: '涡轮鹰',   atk: 3, hp: 3, cost: 3, costType: 'energy', sigils: ['airborne'],       bloodValue: 1, color: '#4a5a7a', glyph: '涡' },
  bison:       { name: '装甲野牛', atk: 4, hp: 4, cost: 4, costType: 'energy', sigils: [],               bloodValue: 1, color: '#5a6a76', glyph: '装' },
  bull:        { name: '蒸汽蛮牛', atk: 5, hp: 4, cost: 4, costType: 'energy', sigils: [],               bloodValue: 1, color: '#6a5a5a', glyph: '汽' },

  // 新增普通卡
  ant:         { name: '工蚁机', atk: 1, hp: 2, cost: 1, costType: 'energy', sigils: [],               bloodValue: 1, color: '#7a6a4a', glyph: '蚁' },
  cricket:     { name: '蟋蟀机', atk: 2, hp: 2, cost: 1, costType: 'energy', sigils: [],               bloodValue: 1, color: '#6a7a4a', glyph: '蟀' },
  sparrow:     { name: '麻雀机', atk: 1, hp: 2, cost: 1, costType: 'energy', sigils: ['airborne'],     bloodValue: 1, color: '#8a7a5a', glyph: '雀' },
  newt:        { name: '蝾螈机', atk: 2, hp: 3, cost: 1, costType: 'energy', sigils: [],               bloodValue: 1, color: '#4a8a6a', glyph: '螈' },
  weasel:      { name: '鼬鼠机', atk: 3, hp: 2, cost: 2, costType: 'energy', sigils: [],               bloodValue: 1, color: '#6a6a76', glyph: '鼬' },

  // 新增：印记演示卡（通用级）
  armor_tank:  { name: '装甲战车', atk: 3, hp: 4, cost: 3, costType: 'energy', sigils: ['armored'],     bloodValue: 1, color: '#6a7a86', glyph: '车' },

  // [daily 2026-08-09] 尖刺甲虫
  spike_beetle: { name: '尖刺甲虫', atk: 3, hp: 2, cost: 2, costType: 'energy', sigils: ['sharp_quills'],  bloodValue: 1, color: '#6a8a4a', glyph: '刺' },
  // [daily 2026-08-09] 自修机甲
  repair_mech: { name: '自修机甲', atk: 3, hp: 3, cost: 3, costType: 'energy', sigils: ['regen'],          bloodValue: 1, color: '#5a8a9a', glyph: '修' },

  // [daily 2026-08-14] 剧毒蜂
  venom_bee:   { name: '剧毒蜂', atk: 2, hp: 2, cost: 2, costType: 'energy', sigils: ['poison_touch'],     bloodValue: 1, color: '#4a8a3a', glyph: '蜂' },

  // [daily 2026-08-15] 齿轮犬
  gear_hound:  { name: '齿轮犬', atk: 2, hp: 2, cost: 2, costType: 'energy', sigils: ['frenzy'],            bloodValue: 1, color: '#5a7a9a', glyph: '齿' },

  // [daily 2026-08-30] 回响机（能量阵营首张「不死」印记卡：首次死亡返手牌，2 费 3/2 廉价钢板）
  echo_droid:  { name: '回响机', atk: 3, hp: 2, cost: 2, costType: 'energy', sigils: ['undying'],            bloodValue: 1, color: '#5a7a9a', glyph: '响' },

  // [daily 2026-09-05] 电弧无人机
  arc_drone:  { name: '电弧无人机', atk: 3, hp: 2, cost: 3, costType: 'energy', sigils: ['airborne'],         bloodValue: 1, color: '#5a8aba', glyph: '弧' },

  // [daily 2026-09-01] 蜂群机（补跑；能量首张「头狼」：3/2 换相邻 +1 攻）
  swarm_bot: { name: '蜂群机', atk: 3, hp: 2, cost: 2, costType: 'energy', sigils: ['pack'], bloodValue: 1, color: '#6a8a6a', glyph: '群' },

  // [daily 2026-09-02] 处决机（补跑；能量首张「致死」：2/4 斩杀铁卫）
  execution_droid: { name: '处决机', atk: 2, hp: 4, cost: 3, costType: 'energy', sigils: ['death_touch'], bloodValue: 1, color: '#5a6a8a', glyph: '决' },

  // [daily 2026-09-03] 自爆机（补跑；1 费易碎敢死队：2/2 打一炮即碎）
  boom_bot: { name: '自爆机', atk: 2, hp: 2, cost: 1, costType: 'energy', sigils: ['brittle'], bloodValue: 1, color: '#b56a3a', glyph: '爆' },

  // ===================== MOX（魔石）=====================
  // 魔石体系：魔石生物(ruby/emerald/sapphire) 免费上场，在场时提供对应颜色的魔石；
  // 其余法术卡 costType='gem'，需场上存在对应颜色的魔石才能召唤（召唤不消耗魔石，
  // 但魔石生物死亡即失去该颜色魔石）。cost 字段对 gem 卡无意义，统一填 0。
  ruby_mox:    { name: '红玉魔石', atk: 0, hp: 1, cost: 0, costType: 'gem', gemCost: [],                mox: 'orange', sigils: [],               bloodValue: 1, color: '#e67e22', glyph: '橙' },
  emerald_mox: { name: '翡翠魔石', atk: 0, hp: 1, cost: 0, costType: 'gem', gemCost: [],                mox: 'green',  sigils: [],               bloodValue: 1, color: '#27ae60', glyph: '绿' },
  sapphire_mox:{ name: '蓝宝魔石', atk: 0, hp: 1, cost: 0, costType: 'gem', gemCost: [],                mox: 'blue',   sigils: [],               bloodValue: 1, color: '#2980b9', glyph: '蓝' },
  imp:         { name: '炎晶小鬼', atk: 1, hp: 1, cost: 0, costType: 'gem', gemCost: ['orange'],              sigils: [],                bloodValue: 1, color: '#6a2a4a', glyph: '鬼' },
  panther:     { name: '暗影魔豹', atk: 2, hp: 1, cost: 0, costType: 'gem', gemCost: ['blue'],                sigils: ['double_strike'], bloodValue: 1, color: '#1a1a2a', glyph: '豹' },
  python:      { name: '翠鳞巨蟒', atk: 2, hp: 1, cost: 0, costType: 'gem', gemCost: ['green'],               sigils: [],                bloodValue: 1, color: '#2a5a3a', glyph: '蟒' },
  demon:       { name: '赤焰恶魔', atk: 2, hp: 1, cost: 0, costType: 'gem', gemCost: ['orange'],              sigils: ['poison_touch'],  bloodValue: 1, color: '#7a2a2a', glyph: '魔' },
  basilisk:    { name: '石化蛇怪', atk: 1, hp: 2, cost: 0, costType: 'gem', gemCost: ['green'],               sigils: ['poison_touch'],  bloodValue: 1, color: '#3a6a3a', glyph: '怪' },
  chimera:     { name: '奇美拉',   atk: 2, hp: 2, cost: 0, costType: 'gem', gemCost: ['green','blue'],        sigils: ['pack'],          bloodValue: 1, color: '#6a4a6a', glyph: '奇' },
  golem:       { name: '符文魔像', atk: 2, hp: 3, cost: 0, costType: 'gem', gemCost: ['orange','green'],      sigils: [],                bloodValue: 1, color: '#8a8a96', glyph: '像' },
  manticore:   { name: '蝎尾狮',   atk: 2, hp: 2, cost: 0, costType: 'gem', gemCost: ['orange','blue'],       sigils: ['double_strike'], bloodValue: 1, color: '#9a5a2a', glyph: '狮' },
  griffin:     { name: '苍空狮鹫', atk: 2, hp: 1, cost: 0, costType: 'gem', gemCost: ['blue'],                sigils: ['airborne'],       bloodValue: 1, color: '#caa84a', glyph: '鹫' },
  phoenix:     { name: '不灭凤凰', atk: 3, hp: 2, cost: 0, costType: 'gem', gemCost: ['green','orange','blue'], sigils: ['undying'],      bloodValue: 1, color: '#c85a2a', glyph: '凤' },
  // 新增普通法术卡（魔石卡均为 0 费，可重复）
  sprite:      { name: '焰灵',   atk: 1, hp: 1, cost: 0, costType: 'gem', gemCost: ['orange'],              sigils: [],                bloodValue: 1, color: '#e07a3a', glyph: '灵' },
  wisp:        { name: '翠灵',   atk: 1, hp: 2, cost: 0, costType: 'gem', gemCost: ['green'],               sigils: ['poison_touch'],  bloodValue: 1, color: '#3a9a5a', glyph: '翠' },
  breeze:      { name: '蓝息',   atk: 1, hp: 1, cost: 0, costType: 'gem', gemCost: ['blue'],                sigils: ['airborne'],       bloodValue: 1, color: '#4a8ad0', glyph: '息' },
  ember:       { name: '余烬',   atk: 2, hp: 1, cost: 0, costType: 'gem', gemCost: ['orange'],              sigils: ['brittle'],        bloodValue: 1, color: '#c85a2a', glyph: '烬' },

  // 新增：印记演示卡（通用级）
  soul_reaper: { name: '噬魂死神', atk: 2, hp: 1, cost: 0, costType: 'gem', gemCost: ['orange','green'],     sigils: ['death_touch'],   bloodValue: 1, color: '#7a2a4a', glyph: '死' },
  // [daily 2026-08-09] 冰晶刺客
  frost_assassin: { name: '冰晶刺客', atk: 2, hp: 1, cost: 0, costType: 'gem', gemCost: ['blue'],              sigils: ['sharp_quills'], bloodValue: 1, color: '#4a8ad0', glyph: '冰' },
  // [daily 2026-08-09] 石鳞卫
  stone_scale: { name: '石鳞卫',   atk: 1, hp: 3, cost: 0, costType: 'gem', gemCost: ['green'],               sigils: ['armored'],       bloodValue: 1, color: '#5a7a4a', glyph: '岩' },

  // [daily 2026-08-12] 霜灵
  frostling:  { name: '霜灵',     atk: 1, hp: 2, cost: 0, costType: 'gem', gemCost: ['blue'],                 sigils: ['frenzy'],        bloodValue: 1, color: '#4a8ad0', glyph: '霜' },

  // [daily 2026-08-15] 熔岩哨
  lava_sentinel: { name: '熔岩哨', atk: 1, hp: 2, cost: 0, costType: 'gem', gemCost: ['orange'],               sigils: ['regen'],         bloodValue: 1, color: '#e07a3a', glyph: '熔' },

  // [daily 2026-08-30] 苔绒精（魔石阵营首张「断尾」印记卡：死亡随机得一只松鼠；需绿魔石）
  moss_imp:    { name: '苔绒精', atk: 1, hp: 2, cost: 0, costType: 'gem', gemCost: ['green'],                 sigils: ['loose_tail'],    bloodValue: 1, color: '#3a9a5a', glyph: '绒' },

  // [daily 2026-08-31] 琥珀兽（补跑；需橙魔石，2/2 狂热滚攻）
  amber_beast: { name: '琥珀兽', atk: 2, hp: 2, cost: 0, costType: 'gem', gemCost: ['orange'],                 sigils: ['frenzy'],        bloodValue: 1, color: '#e0a03a', glyph: '琥' },

  // [daily 2026-09-01] 荆棘藤（补跑；需绿魔石，2/2 尖刺反伤藤蔓）
  thorn_vine:  { name: '荆棘藤', atk: 2, hp: 2, cost: 0, costType: 'gem', gemCost: ['green'],                  sigils: ['sharp_quills'],  bloodValue: 1, color: '#3a8a4a', glyph: '蔓' },

  // [daily 2026-09-02] 双生魔（补跑；需绿+蓝双魔石，2/2 连击）
  twin_fiend:  { name: '双生魔', atk: 2, hp: 2, cost: 0, costType: 'gem', gemCost: ['green','blue'],           sigils: ['double_strike'], bloodValue: 1, color: '#6a4a8a', glyph: '双' },

  // [daily 2026-09-04] 赤瞳魔（补跑；需橙魔石，1/1 致死+易碎：斩杀一次即碎，一次性处决）
  crimson_eye: { name: '赤瞳魔', atk: 1, hp: 1, cost: 0, costType: 'gem', gemCost: ['orange'],                 sigils: ['death_touch','brittle'], bloodValue: 1, color: '#c05a3a', glyph: '瞳' },

  // ==========================================================================
  // 时砂阵营（sand）：核心创新点 = 召唤方式——消耗「剩余出牌时间」(pl.seconds) 召唤，不可透支。
  // 单位数值曲线 1:1 镜像能量阵营（同费同级、攻防分布完全一致：1 费×7 / 2 费×9 /
  // 3 费×3 / 4 费×2 / 0 费×1），仅替换主题化的名字与印记，以保证「消耗秒数」这一
  // 新机制不会破坏六阵营整体平衡（时砂胜率与能量对齐，约 45-54%）。pl.seconds 每回合开局由
  // beginTurn 写入「爬升预算」= BASE + 己方回合数×STEP、封顶 CAP（默认 2/1/5 秒），真实流逝
  // + 出牌扣减都会消耗它，归零则回合结束——时间即资源、不跨回合累计（每回合从 BASE 重计）。
  // 成本曲线已压到 ≤ CAP(5秒)，保证每张牌在预算内可打出。
  sand_pebble:     { name: '砂砾',   atk: 0, hp: 1, cost: 2, costType: 'sand', sigils: [],                  bloodValue: 1, color: '#c2b280', glyph: '砾' },
  sand_apprentice: { name: '时砂学徒', atk: 1, hp: 1, cost: 4, costType: 'sand', sigils: [],                bloodValue: 1, color: '#d8c48a', glyph: '徒' },
  pendulum:        { name: '钟摆兽', atk: 2, hp: 2, cost: 3, costType: 'sand', sigils: ['sharp_quills'],  bloodValue: 1, color: '#c9a24a', glyph: '摆' },
  chrono_twin:     { name: '双刻兽', atk: 2, hp: 2, cost: 3, costType: 'sand', sigils: ['sharp_quills'],  bloodValue: 1, color: '#d0a84a', glyph: '孪' },
  sand_swift:      { name: '流沙隼', atk: 2, hp: 1, cost: 3, costType: 'sand', sigils: ['airborne'],        bloodValue: 1, color: '#c8b070', glyph: '隼' },
  gear_beetle:     { name: '齿甲',   atk: 2, hp: 2, cost: 3, costType: 'sand', sigils: ['sharp_quills'],    bloodValue: 1, color: '#9a8a4a', glyph: '甲' },
  sand_panther:    { name: '时影豹', atk: 2, hp: 2, cost: 3, costType: 'sand', sigils: [],                  bloodValue: 1, color: '#a98a4a', glyph: '影' },
  sand_wisp:       { name: '流沙精', atk: 1, hp: 2, cost: 3, costType: 'sand', sigils: ['poison_touch'],    bloodValue: 1, color: '#b59a4a', glyph: '沙' },
  clock_hound:     { name: '时犬',   atk: 1, hp: 2, cost: 3, costType: 'sand', sigils: ['frenzy'],          bloodValue: 1, color: '#a98a4a', glyph: '犬' },
  rewind_owl:      { name: '回溯枭', atk: 2, hp: 2, cost: 3, costType: 'sand', sigils: ['regen'],           bloodValue: 1, color: '#a9b0c0', glyph: '枭' },
  sand_eagle:      { name: '时涡鹰', atk: 2, hp: 3, cost: 5, costType: 'sand', sigils: ['airborne'],        bloodValue: 1, color: '#7fb0c0', glyph: '涡' },
  chrono_knight:    { name: '时之骑士', atk: 2, hp: 4, cost: 5, costType: 'sand', sigils: ['armored'],       bloodValue: 1, color: '#b8a85a', glyph: '骑' },
  sand_golem:      { name: '砂岩魔像', atk: 2, hp: 3, cost: 5, costType: 'sand', sigils: ['regen'],          bloodValue: 1, color: '#c8b070', glyph: '像' },
  hourglass_titan: { name: '沙漏泰坦', atk: 3, hp: 4, cost: 5, costType: 'sand', sigils: ['frenzy'],         bloodValue: 1, color: '#e0b03a', glyph: '泰' },
  chronolord:      { name: '时主',   atk: 4, hp: 4, cost: 5, costType: 'sand', sigils: ['undying','regen'], bloodValue: 1, color: '#d0b060', glyph: '主' },
  eternal_sand:    { name: '永恒之砂', atk: 4, hp: 6, cost: 5, costType: 'sand', sigils: ['regen','undying'], bloodValue: 1, color: '#ffd24a', glyph: '永', premium: true },

  // —— 机械 / 钟表 / 指针 主题卡（v0.7.0 新增，替换 8 张通用砂生物填充卡）——
  mainspring_mouse: { name: '发条鼠',   atk: 1, hp: 1, cost: 3, costType: 'sand', sigils: ['loose_tail'],    bloodValue: 1, color: '#b08d57', glyph: '鼠' },
  gear_fly:        { name: '齿轮蝇',   atk: 1, hp: 2, cost: 4, costType: 'sand', sigils: ['airborne'],       bloodValue: 1, color: '#9a8a4a', glyph: '蝇' },
  escapement:      { name: '擒纵轮',   atk: 1, hp: 2, cost: 3, costType: 'sand', sigils: [],                 bloodValue: 1, color: '#a8985a', glyph: '擒' },
  hairspring:      { name: '游丝',     atk: 1, hp: 3, cost: 4, costType: 'sand', sigils: ['regen'],          bloodValue: 1, color: '#c0c0d0', glyph: '丝' },
  second_hand:     { name: '秒针',     atk: 1, hp: 1, cost: 3, costType: 'sand', sigils: ['airborne'], bloodValue: 1, color: '#c9a24a', glyph: '秒' },
  hour_hand:       { name: '时针',     atk: 1, hp: 3, cost: 3, costType: 'sand', sigils: ['armored'],        bloodValue: 1, color: '#b8a85a', glyph: '时' },
  minute_hand:     { name: '分针',     atk: 2, hp: 3, cost: 4, costType: 'sand', sigils: ['sharp_quills'],   bloodValue: 1, color: '#c9a24a', glyph: '分' },
  brass_automaton: { name: '黄铜傀儡', atk: 2, hp: 3, cost: 4, costType: 'sand', sigils: [],                 bloodValue: 1, color: '#b08d57', glyph: '铜' },

  // ==========================================================================
  // 军威阵营（morale）：核心创新点 = 召唤方式——消耗「士气」召唤。士气由「交战造成
  // 伤害」累积（攻击敌方单位 +1/伤害、致死算满血、尖刺反伤同样产士气），跨回合累计、
  // 存量封顶 MORALE_CAP、单回合获取封顶 MORALE_GAIN_PER_TURN_CAP、开局 0、无无偿发放。
  // **攻击天平（直击空列/飞行越界）不再产士气**——初版含此导致 88% 失衡（攻击取胜动作
  // 既推胜利又滚经济双重碾压），改交战伤害后才平衡。用户要求「最廉价单位、费用相对高」，
  // 故身材压到廉价端（同费比其它阵营略弱），靠「打敌方单位即回本」的正反馈滚雪球。
  // 0费×1 / 1费×3 / 2费×6 / 3费×3 / 4费×3 + 1 付费神话。
  war_drummer:      { name: '战鼓手',   atk: 1, hp: 1, cost: 0, costType: 'morale', sigils: [],                bloodValue: 1, color: '#c89a6a', glyph: '鼓' },
  war_piper:        { name: '战笛手',   atk: 1, hp: 1, cost: 1, costType: 'morale', sigils: ['brittle'],       bloodValue: 1, color: '#c09060', glyph: '笛' },
  outrider:         { name: '游骑',     atk: 2, hp: 1, cost: 1, costType: 'morale', sigils: [],                bloodValue: 1, color: '#b5754a', glyph: '骑' },
  scout_raven:      { name: '斥候鸦',   atk: 1, hp: 2, cost: 1, costType: 'morale', sigils: ['airborne'],      bloodValue: 1, color: '#9a8a6a', glyph: '鸦' },
  spearman:         { name: '矛兵',     atk: 2, hp: 1, cost: 1, costType: 'morale', sigils: [],                bloodValue: 1, color: '#b07040', glyph: '矛' },
  warhound:         { name: '战犬',     atk: 2, hp: 1, cost: 2, costType: 'morale', sigils: [],                bloodValue: 1, color: '#a85a2a', glyph: '犬' },
  pikeman:          { name: '长矛兵',   atk: 1, hp: 3, cost: 2, costType: 'morale', sigils: [],                bloodValue: 1, color: '#a05a30', glyph: '枪' },
  drummer_chief:    { name: '鼓长',     atk: 2, hp: 2, cost: 2, costType: 'morale', sigils: ['frenzy'],        bloodValue: 1, color: '#b06030', glyph: '帅' },
  shield_guard:     { name: '盾卫',     atk: 1, hp: 4, cost: 2, costType: 'morale', sigils: ['armored'],       bloodValue: 1, color: '#9a6a4a', glyph: '盾' },
  standard_bearer:   { name: '旗手',     atk: 2, hp: 2, cost: 2, costType: 'morale', sigils: ['pack'],          bloodValue: 1, color: '#a05028', glyph: '旗' },
  archer:           { name: '弩手',     atk: 2, hp: 1, cost: 2, costType: 'morale', sigils: [],                bloodValue: 1, color: '#b8682a', glyph: '弩' },
  knight_errant:    { name: '游侠骑士', atk: 3, hp: 2, cost: 3, costType: 'morale', sigils: ['armored'],       bloodValue: 1, color: '#9a4a1a', glyph: '侠' },
  berserker:        { name: '狂战士',   atk: 2, hp: 2, cost: 3, costType: 'morale', sigils: [],                bloodValue: 1, color: '#8a3a14', glyph: '狂' },
  champion:         { name: '冠军',     atk: 2, hp: 3, cost: 3, costType: 'morale', sigils: ['regen'],         bloodValue: 1, color: '#a05a2a', glyph: '冠' },
  lancer:           { name: '骑枪兵',   atk: 4, hp: 2, cost: 4, costType: 'morale', sigils: ['double_strike'], bloodValue: 1, color: '#7a3a14', glyph: '刺' },
  general:          { name: '将军',     atk: 3, hp: 3, cost: 4, costType: 'morale', sigils: [],                bloodValue: 1, color: '#6a2a10', glyph: '将' },
  war_elephant:    { name: '战象',     atk: 4, hp: 3, cost: 4, costType: 'morale', sigils: ['armored'],       bloodValue: 1, color: '#7a4a1a', glyph: '象' },
  avatar_of_war:    { name: '战神化身', atk: 5, hp: 5, cost: 5, costType: 'morale', sigils: ['regen','undying'],bloodValue: 2, color: '#d4a040', glyph: '神', premium: true },

  // ===================== 神话卡（premium / mythic）=====================
  // 仅可通过魂晶（付费货币）获取：暗夜卡包极低概率掉落 或 直购商店高价购买。
  // 设计原则：比同费用普通卡略强（+1 stat 或多一个印记），但有明确弱点（脆皮/高费/多宝石需求）。
  // 视觉特色：专属宇宙星云背景 + 金色光环 + 动画边框。
  // blood_titan: 比bear(5/4/4)多1攻1血+frenzy，但4费血肉需献祭2只单位。
  blood_titan:    { name: '血肉巨人', atk: 6, hp: 5, cost: 4, costType: 'blood', sigils: ['frenzy'],                bloodValue: 2, color: '#8a0a1a', glyph: '巨', premium: true },
  // vampire_queen: 比dire_wolf(3/3/3)多1血+双印记(回复+致死)，3费需1.5只献祭。
  vampire_queen:  { name: '吸血女王', atk: 3, hp: 4, cost: 3, costType: 'blood', sigils: ['regen','death_touch'],     bloodValue: 2, color: '#6a0a2a', glyph: '吸', premium: true },
  // lich_king: 4费骸骨（需4回合滴流），不死+回复极难杀，但攻击力偏低。
  lich_king:      { name: '巫妖之王', atk: 3, hp: 5, cost: 4, costType: 'bone',  sigils: ['regen','undying'],        bloodValue: 1, color: '#2a1a4a', glyph: '巫', premium: true },
  // bone_dragon: 4费骸骨，飞行+连击=8点直击天平，但3血很脆。
  bone_dragon:    { name: '骨龙',     atk: 4, hp: 3, cost: 4, costType: 'bone',  sigils: ['airborne','double_strike'],bloodValue: 1, color: '#d8d0c0', glyph: '龙', premium: true },
  // omega_core: 5费能量（满能才可出），铁桶+回复，终局终结者。
  omega_core:     { name: '欧米伽核心', atk: 5, hp: 5, cost: 5, costType: 'energy', sigils: ['armored','regen'],      bloodValue: 1, color: '#0a3a5a', glyph: 'Ω',  premium: true },
  // storm_harrier: 3费能量，飞行+连击=8点空袭，但2血极易被远程/法术清除。
  storm_harrier:  { name: '风暴鹞',   atk: 4, hp: 2, cost: 3, costType: 'energy', sigils: ['airborne','double_strike'],bloodValue: 1, color: '#2a6aaa', glyph: '风', premium: true },
  // archmage: 需三色全宝石，双印记(连击+回复)，终极魔石回报。
  archmage:       { name: '大法师',   atk: 4, hp: 4, cost: 0, costType: 'gem', gemCost: ['orange','green','blue'], sigils: ['double_strike','regen'], bloodValue: 1, color: '#6a2a8a', glyph: '法', premium: true },
  // void_phantom: 需2色宝石，飞行+致死，极难被地面单位处理。
  void_phantom:   { name: '虚空幻影', atk: 3, hp: 3, cost: 0, costType: 'gem', gemCost: ['orange','blue'],        sigils: ['airborne','death_touch'], bloodValue: 1, color: '#3a0a3a', glyph: '虚', premium: true },
};

// Faction metadata + the card pool the deck builder offers for each faction.
export const FACTIONS = {
  blood: {
    key: 'blood', name: '血肉', res: 'blood', color: '#b5341f',
    desc: '每回合获得 1 点「当回合血肉」（不攒、回合开始重置，可单独召唤 1 费牌）。更高费用的血肉牌需在当回合血肉基础上，额外献祭场上已召唤的单位来支付。0 费牌可直接打出，作为铺场与祭品。',
    cards: ['squirrel','stoat','raven','mole','beaver','adder','raccoon','opossum','wolf','bullfrog','vulture','cougar','dire_wolf','hound','skunk','great_white','warthog','bear','wolf_cub','field_mouse','toad','shrew','hawk','ferret','viper_king','warg','rat_king','berserker','armored_badger','hedgehog','porcupine','otter','fire_salamander','pangolin','giant_croc','mongoose','kite','blood_titan','vampire_queen'],
  },
  bone: {
    key: 'bone', name: '骸骨', res: 'bone', color: '#9aa0a8',
    desc: '亡灵墓地大军：你的生物「以任何方式死亡」（交战阵亡 / 0 费易碎生物攻击后碎裂 / 致死等）每只掉落 1 点骸骨，另有极轻的每回合墓地滴流（约 0.75，攒满 1 才 +1，仅防前期断档）。用骸骨召唤亡灵，用 0 费「枯骨幼犬」免费铺场、送死换骸骨。',
    cards: ['bone_pup','rat','cat','spider','bat','skeleton','corpse','crab','scorpion','zombie','black_widow','turtle','bone_hound','geck','lizard','snail','moth','beetle','bonesnake','bone_warden','grave_moss','tomb_guard','bone_archer','soul_bone','wailing_spirit','ghoul','gravedigger','carrion_beast','dread_knight','lich_king','bone_dragon'],
  },
  energy: {
    key: 'energy', name: '能量', res: 'energy', color: '#3a8ad0',
    desc: '机械军团：能量每回合从 1 点爬升至 6 点封顶、整回满，指挥钢铁与电路组成的战争机器。',
    cards: ['black_cat','magpie','fennec','peacock','lynx','mantis','falcon','ram','grey_jaguar','eagle','bison','bull','ant','cricket','sparrow','newt','weasel','armor_tank','spike_beetle','repair_mech','venom_bee','gear_hound','echo_droid','arc_drone','swarm_bot','execution_droid','boom_bot','omega_core','storm_harrier'],
  },
  mox: {
    key: 'mox', name: '魔石', res: 'mox', color: '#9a4ad0',
    desc: '魔石体系：上场「魔石生物」(红玉/翡翠/蓝宝) 即可获得对应颜色的魔石。法术卡需要场上存在对应颜色的魔石才能召唤——魔石不消耗，但魔石生物一旦死亡就会失去该魔石。',
    cards: ['ruby_mox','emerald_mox','sapphire_mox','imp','panther','python','demon','basilisk','chimera','golem','manticore','griffin','phoenix','sprite','wisp','breeze','ember','soul_reaper','frost_assassin','stone_scale','frostling','lava_sentinel','moss_imp','amber_beast','thorn_vine','twin_fiend','crimson_eye','archmage','void_phantom'],
  },
  sand: {
    key: 'sand', name: '时砂', res: 'sand', color: '#e0b03a',
    desc: '时间即是资源：每回合开局获得一份「出牌时间」预算，它随你的回合数小幅增长（首回合 2 秒，每多一个己方回合 +1 秒、封顶 5 秒）——它是你这一回合真实倒计时的时钟。真实流逝每过 1 秒就少 1 秒，出牌再额外扣掉该牌的「秒费」，归零则回合自动结束。卡牌以「秒」为费、不可透支（例如剩 4 秒打不出 5 秒的牌）。每回合归零重计、不跨回合累计（时砂越战越从容，但每回合从 2 秒重新流）。主题：时钟机械、指针（时针/分针/秒针）、齿轮、发条、擒纵、游丝、沙漏、流沙与时光生物。',
    cards: ['sand_apprentice','sand_pebble','pendulum','chrono_twin','sand_swift','gear_beetle','sand_panther','sand_wisp','clock_hound','rewind_owl','sand_eagle','chrono_knight','sand_golem','hourglass_titan','chronolord','mainspring_mouse','gear_fly','escapement','hairspring','second_hand','hour_hand','minute_hand','brass_automaton'],
  },
  // === 占位阵营（即将推出）：预留第 6 / 7 / 8 阵营插槽，目前 cards 为空、comingSoon:true。
  // 具体内容（核心召唤机制 / 卡池 / 资源）以后填充；填好后删掉 comingSoon 并把 key 加进
  // balance_sim.mjs / balance_pairwise.mjs 的硬编码阵营数组即可纳入平衡。
  morale: {
    key: 'morale', name: '军威', res: 'morale', color: '#b5651d',
    desc: '军威以「士气」为资源：交战造成伤害（攻击敌方单位、含致死与尖刺反伤）给全额士气（1 伤=1 士气，受单回合获取上限）；攻击天平（直击空列/飞行越界）给折减系数 0.22 的士气（分数累积）。士气跨回合累计、存量封顶 10、单回合获取封顶 4、开局 0、无无偿发放。初版天平满额导致 88% 失衡（攻击取胜动作既推胜利又滚经济双重碾压），改折减后才平衡。士气卡消耗士气召唤——单位身材压到廉价端，靠「打敌方单位即回本」的正反馈滚雪球。',
    cards: ['war_drummer','war_piper','outrider','scout_raven','spearman','warhound','pikeman','drummer_chief','shield_guard','standard_bearer','archer','knight_errant','berserker','champion','lancer','general','war_elephant','avatar_of_war'],
  },
  f7: {
    key: 'f7', name: '阵营七', res: 'tbd', color: '#8a7c94',
    desc: '即将推出（敬请期待）。',
    cards: [], comingSoon: true,
  },
  f8: {
    key: 'f8', name: '阵营八', res: 'tbd', color: '#7c9490',
    desc: '即将推出（敬请期待）。',
    cards: [], comingSoon: true,
  },
};

// Ready-made decks (arrays of card ids), kept for quick-start / AI opponents.
// 规则：有费卡（含需特定魔石的魔石法术卡）每张限 1 张，0 费免费卡可重复（2 份）。
function deckCopies(id) { return isCostedCard(id) ? 1 : 2; }
// 神话卡不进入默认卡组（AI 和玩家初始牌组都不含 premium 卡）
const _nonPremium = (id) => !CARDS[id] || !CARDS[id].premium;
export const DECKS = {
  blood:  FACTIONS.blood.cards.filter(_nonPremium).flatMap((id) => Array(deckCopies(id)).fill(id)),
  bone:   FACTIONS.bone.cards.filter(_nonPremium).flatMap((id) => Array(deckCopies(id)).fill(id)),
  energy: FACTIONS.energy.cards.filter(_nonPremium).flatMap((id) => Array(deckCopies(id)).fill(id)),
  mox:    FACTIONS.mox.cards.filter(_nonPremium).flatMap((id) => Array(deckCopies(id)).fill(id)),
  sand:   FACTIONS.sand.cards.filter(_nonPremium).flatMap((id) => Array(deckCopies(id)).fill(id)),
  morale: FACTIONS.morale.cards.filter(_nonPremium).flatMap((id) => Array(deckCopies(id)).fill(id)),
};

// Build a default deck for a faction (each card x2, padded to a sane size).
export function defaultDeck(factionKey) {
  const f = FACTIONS[factionKey];
  if (!f) return DECKS.blood.slice();
  const out = [];
  for (const id of f.cards) {
    if (CARDS[id] && CARDS[id].premium) continue;   // 神话卡不进入默认卡组
    const n = isCostedCard(id) ? 1 : 2;   // 有费的卡（含需魔石的法术卡）每张限 1 张
    for (let i = 0; i < n; i++) out.push(id);
  }
  return out.slice(0, CONFIG.DECK_MAX);
}

export function getCard(id) { return CARDS[id]; }

// ============================================================================
// COLLECTION / RARITY / GACHA
// ============================================================================
// Rarity tiers drive gacha drop weights, dust (coin) refunds on duplicates,
// and card-frame colors. Higher rarity = rarer & shinier.
export const RARITY = {
  common: { key: 'common', name: '普通', color: '#9aa0a8', glow: 'rgba(154,160,168,.5)', weight: 62, dust: 15 },
  rare:   { key: 'rare',   name: '稀有', color: '#3a9ad0', glow: 'rgba(58,154,208,.65)', weight: 27, dust: 35 },
  epic:   { key: 'epic',   name: '史诗', color: '#a95ad0', glow: 'rgba(169,90,208,.7)',  weight: 9,  dust: 90 },
  legend: { key: 'legend', name: '传说', color: '#e0b03a', glow: 'rgba(224,176,58,.8)',  weight: 2,  dust: 220 },
  mythic: { key: 'mythic', name: '神话', color: '#ff3366', glow: 'rgba(255,51,102,.9)',  weight: 0,  dust: 500 },
  // mythic: weight=0 → 永不出现在普通包；仅暗夜包有极低概率；直购价格极高。
};
export const RARITY_ORDER = ['common', 'rare', 'epic', 'legend', 'mythic'];

// A few explicit rarity overrides for signature cards; everything else is
// derived from cost / gem complexity below.
const RARITY_OVERRIDE = {
  squirrel: 'common', bone_pup: 'common',
  bear: 'legend', phoenix: 'legend', great_white: 'epic',
  cougar: 'epic', dire_wolf: 'epic', black_widow: 'epic', turtle: 'epic',
  // Ensure every faction has enough starter (common) cards for a 10-card deck:
  grey_jaguar: 'common',                       // energy: brings commons to 5 (x2 = 10)
  imp: 'common', python: 'common', griffin: 'common', // mox: 3 generators + 1 payoff per color
  // New sigil demo cards are common so they're immediately playable & testable:
  viper_king: 'common', bone_warden: 'common', armor_tank: 'common', soul_reaper: 'common',
  warg: 'common', rat_king: 'common', berserker: 'common',
  // Mythic (premium) cards — only obtainable via Soul Crystals (魂晶)
  blood_titan: 'mythic', vampire_queen: 'mythic',
  lich_king: 'mythic', bone_dragon: 'mythic',
  omega_core: 'mythic', storm_harrier: 'mythic',
  archmage: 'mythic', void_phantom: 'mythic',
};

export function rarityOf(id) {
  if (RARITY_OVERRIDE[id]) return RARITY_OVERRIDE[id];
  const c = CARDS[id];
  if (!c) return 'common';
  if (c.costType === 'gem') {
    if (c.mox) return 'common';                 // Mox generator creatures are basic
    const n = (c.gemCost || []).length;
    return n >= 3 ? 'legend' : n === 2 ? 'epic' : 'rare';
  }
  const cost = c.cost || 0;
  return cost >= 4 ? 'legend' : cost >= 3 ? 'epic' : cost >= 2 ? 'rare' : 'common';
}

export function allCardIds() { return Object.keys(CARDS); }

// Cards a brand-new player owns for free: every "common" tier card, so each
// faction has enough basics to build a starter deck immediately. Everything
// rarer starts LOCKED and must be earned through card packs.
//
// 注：时砂阵营的卡牌因为 costType 是 'sand'（按默认 rarity 推断公式 cost≥2=rare），
// 一张 common 都没有 → 旧实现下"全是 common"的策略会让时砂玩家一张也组不出。
// 因此把 "每个阵营的非付费 non-premium 卡" 都视为基础卡池一并解锁（每个阵营都保留
// 几张有费 1-3 费的常用生物，足够开局组一套完整卡组；神话 premium 卡仍只能魂晶抽到）。
export function starterUnlocked() {
  const base = new Set(allCardIds().filter((id) => rarityOf(id) === 'common'));
  for (const fk of Object.keys(FACTIONS)) {
    for (const id of FACTIONS[fk].cards) {
      const c = CARDS[id];
      if (!c || c.premium) continue;
      base.add(id);
    }
  }
  return [...base];
}

// Migrate an old profile so a faction that was added AFTER the profile was first
// saved still has its non-premium basics in `unlocked`. Call from profile.js#normalize
// when loading any existing save (idempotent: uses Set semantics).
export function defaultUnlockedForAllFactions() {
  const out = new Set();
  for (const fk of Object.keys(FACTIONS)) {
    for (const id of FACTIONS[fk].cards) {
      const c = CARDS[id];
      if (!c || c.premium) continue;
      out.add(id);
    }
  }
  return out;
}

// Card pack economy.
export const PACK = {
  cost: 100,          // coins per pack
  startCoins: 800,    // coins a new profile begins with
  winReward: 120,     // coins for winning a match
  loseReward: 40,     // consolation coins
  residualDupChance: 0,    // 0 = 图鉴未集齐前绝不重复（始终从"未拥有"卡池抽取）；集齐后才会必然重复并按稀有度返还金币
};

// ============================================================================
// PREMIUM CURRENCY: 魂晶 (Soul Crystals 💎)
// ============================================================================
// 魂晶是充值获得的付费货币。金币是免费游戏货币（对战获取）。
// 魂晶用途：① 暗夜卡包（保底稀有+，更高史诗/传说概率）
//           ② 直购指定卡牌（跳过随机，按稀有度定价）
//           ③ 兑换金币（1 魂晶 = 25 金币）

// 暗夜卡包：魂晶购买，掉率大幅优于普通包（保底 rare+）
// mythic 卡仅通过暗夜包极低概率掉落或直购获得，普通包永不出。
export const GEM_PACK = {
  cost: 30,           // 魂晶 per pack
  // 掉率权重：common 被压制，epic/legend 大幅提升，mythic 极低概率
  weights: { common: 20, rare: 38, epic: 26, legend: 12, mythic: 4 },
  // 保底机制：最低稀有度 = rare（不会出 common）
  minRarity: 'rare',
  residualDupChance: 0,   // 同普通包：图鉴未集齐前不重复
};

// 直购商店：按稀有度定价（魂晶）
export const CARD_SHOP_PRICES = {
  common: 5,
  rare: 15,
  epic: 40,
  legend: 100,
  mythic: 200,   // 神话卡直购价格极高
};

// 充值档位（模拟支付，无真实交易）
export const RECHARGE_PACKAGES = [
  { id: 'r6',   price: 6,   gems: 60,   bonus: 0,   label: '入门' },
  { id: 'r30',  price: 30,  gems: 300,  bonus: 30,  label: '日常' },
  { id: 'r98',  price: 98,  gems: 980,  bonus: 150, label: '超值' },
  { id: 'r328', price: 328, gems: 3280, bonus: 600, label: '豪礼' },
];

// 魂晶兑换金币
export const GEM_EXCHANGE = {
  rate: 25,           // 1 魂晶 = 25 金币
  minGems: 1,         // 最低兑换 1 魂晶
};

// ===================== 更新日志（产品内可见，最新在前）=====================
// 每日新增卡牌自动化会在头部追加当日条目；手动重大改动也写在这里。
export const CHANGELOG = [
  {
    version: 'v0.7.9',
    date: '2026-09-05',
    title: '时砂改为真实出牌倒计时 + 每日新增卡牌',
    items: [
      '时砂(sand)机制重写——「召唤方式」从「恒定秒能预算」改为「真实出牌倒计时」：每回合开局获得一份出牌时间预算（BASE 2 / 每多一个己方回合 +1 / 封顶 CAP 5 秒），它随真实时间每秒流逝、出牌再额外扣对应秒费、归零则回合自动结束（时间即资源、不可透支、不跨回合累计）。',
      '修复此前结构性 OP：旧模型每回合恒定给足秒数，时砂必能每回合打出真打手戳空列推天平，在「分数差 5 分」模式下约 3 回合速胜、胜率 90%+。新模型让时砂前几回合只够打砂砾级弱牌（与能量阵营能量从 1 爬升对齐），六阵营无头仿真（PER=500）spread 7.5pt（≤10），时砂 54.0% 与能量同档，不再碾压。',
      '全链路接入：engine 的 beginTurn 按爬升预算写入 pl.seconds、playCard sand 分支校验；main.js 计时器驱动 pl.seconds 真实衰减、顶栏显示「出牌 Xs」、归零 autoEndTurn；ui.js 移除独立的「剩余秒数」资源条（时砂资源即时钟）；balance_sim 参数覆盖改为 SAND_BUDGET_CAP/STEP/BASE 并加 turnTime。',
      '每日新增卡牌（2026-09-05）：血肉「火蝾螈」(1/1 · 1 血肉 · 回复)、骸骨「哀号幽魂」(1/1 · 2 骸骨 · 双重打击)、能量「电弧无人机」(3/2 · 3 能量 · 飞行)，六阵营卡池各 +1、平衡无显著偏移。',
      '资源爬升改为「小数滴流」并重校六阵营平衡——能量/时砂的爬升原是整数取模，只能整档跳（能量每 2 回合 +1 仅 44%、每回合 +1 飙到 83%，中间无档可停；时砂每回合 +1 约 55%、每 2 回合 +1 崩到 17.7%）。改为每回合累加小数、满 1 才 +1（与骸骨 BONE_PER_TURN 同源）：ENERGY_RAMP_FRAC=0.65（取「第 3 回合凑满 2 能量」断崖前最高档）、BONE_PER_TURN 0.75→0.85、SAND_RAMP_FRAC=1.0 不变。最终六阵营 normal（PER=500×2 复跑）spread 8.7pt（≤10）。',
      '已知事项：困难难度下骸骨偏高（61.6%，PER=500×2），系每日加卡提交遗留、与本次改动无关（基线对照 17.1–17.3pt 一致），后续单独处理。',
    ],
  },
  {
    version: 'v0.7.8',
    date: '2026-08-17',
    title: '第六阵营「军威」：造成伤害即攒士气',
    items: [
      '新阵营「军威(morale)」上线——第六套独立召唤方式：消耗「士气」召唤，士气由「交战造成伤害」累积（攻击敌方单位、含致死算满血、尖刺反伤），跨回合累计、存量封顶 10、单回合获取封顶 4、开局 0、无无偿发放。',
      '与现有五套召唤方式排他（血肉献祭 / 骸骨死亡 / 能量爬升 / 魔石存在 / 时砂秒数），是第六种：打敌方单位即资源。前期靠 0 费战鼓手造成伤害攒士气启动，中后期靠廉价高性价比单位滚雪球。',
      '18 张军威卡（0费×1 / 1费×3 / 2费×6 / 3费×3 / 4费×3 + 1 张付费神话「战神化身」），主题=军阵/战鼓/旌旗/战兽；单位身材压到廉价端（同费比其它阵营略弱）。',
      '引擎：pl.morale 字段、playCard morale 分支、fight() 累积士气（实际交战伤害、致死算满血、尖刺反伤同样产全额）、resolveAttacks() 天平伤害按 MORALE_SCALE_RATE=0.22 折减累积（分数累积 moraleScaleFrac，避免攻击取胜动作既推胜利又滚经济双重碾压——初版天平满额导致 88% 失衡，改折减后六阵营 spread 5.5pt）、beginTurn 重置单回合获取计数、addMorale 按获取上限截断；开局 ensureMoraleStarterInHand 送战鼓手。',
      '全链路接入：ai canAfford / ui canPlayCard+成本角标「气」+资源条+阵营卡 / main 顶栏士气+resDescShort / profile collection 自动含 / balance_sim+pairwise 阵营数组加 morale。平衡仿真调参至 spread≤10。',
    ],
  },
  {
    version: 'v0.7.7',
    date: '2026-08-17',
    title: '预留「八大阵营」框架空位',
    items: [
      '在 FACTIONS 中新增第 6/7/8 阵营的占位插槽（f6 / f7 / f8），cards 为空、标记 comingSoon:true，仅预留数据结构，不实现机制与卡池。',
      '组卡器 / 收藏页 / 玩法说明均显示「即将推出」灰槽；教程选阵营与所有「能开战」的入口已过滤 comingSoon，占位阵营不会被选中开战，也不进入平衡仿真（平衡脚本为各自硬编码的阵营数组）。',
      '将来要落地某阵营时：填好该占位的 name / color / 资源机制 / cards，删掉 comingSoon，并把 key 加进 balance_sim.mjs 与 balance_pairwise.mjs 的阵营数组即可。',
    ],
  },
  {
    version: 'v0.7.6',
    date: '2026-08-16',
    title: '时砂阵营终于能玩了（修复基础卡池解锁 + 老存档迁移）',
    items: [
      '修时砂阵营"卡组数量永远是 0、根本开不了战"的根因：starterUnlocked 此前只解锁所有 common 卡，而时砂阵营按 rarity 推断公式全部是 rare+（一张 common 都没有），导致老存档与新玩家的收藏里 22 张时砂卡全是 🔒。',
      'constants.js#starterUnlocked 改为「每个阵营的 non-premium 卡都视为基础卡」一并解锁，让所有玩家（血/骨/能/魔/砂）都能立即组出一套像样的卡组。神话卡（premium）仍只能魂晶抽到，经济原则不破。',
      'profile.js#normalize 增加轻量迁移：加载任何存档时把 defaultUnlockedForAllFactions 并入 unlocked（idempotent / Set 去重）。老玩家这次刷新页面就能直接进时砂组卡器；同时这段迁移也是「未来再新增阵营时，自动给老用户补基础卡」的通用模板。',
    ],
  },
  {
    version: 'v0.7.5',
    date: '2026-08-16',
    title: '时砂开局即送「新手牌」',
    items: [
      '新增时砂新手牌「时砂学徒」（1-1 / 2 秒费 / 时砂生物，主题：初入时间的学徒），并加入时砂卡池与默认卡组。',
      '对齐魔石阵营的「开局即送」机制：新增 ensureSandStarterInHand，对时砂玩家保证开局手牌里必有一张时砂学徒（即使牌库是别的阵营也会直接送一张）。它像其它 2 秒费时砂牌一样第 1-2 回合因秒能不足而灰显，第 3 回合金能到 2 时即可打出，保证时砂永不缺可发展的时砂生物。数值经无头仿真校准：五阵营 spread 3.2pt（≤10），时砂不再偏强。',
    ],
  },
  {
    version: 'v0.7.4',
    date: '2026-08-16',
    title: '对战内可折叠「键位小抄」浮窗',
    items: [
      '新增对战内键位小抄浮窗：按 <b>K</b> 或反引号 <b>`</b> 随时呼出 / 收起（也可点控制区「⌨ 键位」按钮）。浮窗读取当前生效键位（含自定义后绑定），紧凑列出战斗全部快捷键：选/放牌、移动光标、结束回合、1-4 指定列、取消、投降、求和、6 个表情。',
      '小抄浮窗与「⚙ 键位设置」同源（共用 keybinds），改键后小抄同步更新；对局结束后仍可呼出查看。玩法说明「六、键盘操作」节也补注了 K / ` 呼出小抄的提示。',
    ],
  },
  {
    version: 'v0.7.3',
    date: '2026-08-16',
    title: '玩法说明接入键位一览 · 表情音效',
    items: [
      '「玩法说明」新增「六、键盘操作（可自定义）」节：动态读取当前生效键位（含你自定义后的绑定），分「对战界面 / 组卡界面」两张表展示全部快捷键与 WASD 主轴说明，并提示输入框打字不误触、设置里按任意键重绑。',
      '表情新增专属音效（emote）：发送任意表情时播放短促上扬提示音，不再复用 click；线上对局音效仅本地播放、不影响转发。',
    ],
  },
  {
    version: 'v0.7.2',
    date: '2026-08-16',
    title: '自定义键位（WASD 为主轴）+ 表情系统 + 组卡 Shift±5 快捷',
    items: [
      '新增「⚙ 键位设置」（主菜单入口）：战斗 / 组卡两套上下文的全部动作均可重绑，点「修改」后按任意键即生效，Esc 取消本次重绑，「恢复默认键位」一键回退；改动即时存入本机浏览器（localStorage），下次自动生效。',
      '广泛应用 WASD：战斗中 A/D（含 ←/→）移动光标（未选牌移手牌、选中后移列），W 选牌 / 在光标列放牌，S/Esc 取消；组卡中 WASD 移动卡牌焦点。',
      '战斗可绑动作：移动光标、选牌/放牌、结束回合、1-4 指定列出牌、投降（F）、求和（P）、以及 6 个表情（默认 Q/E/R/T/G/H）。数字 1-9 仍作为内置快捷（未选牌直接选该张、选中后在 1-4 列打出）。',
      '新增表情系统：战斗界面 6 个表情按钮（👍😂😡🙏🔥💀），点击或按键发送，发送方一侧浮层弹出；线上 P2P 对局会实时转发给对方（房主=A / 挑战者=B）。',
      '组卡新增「选卡组快捷」：Shift + → 给焦点卡 +5、Shift + ← 给焦点卡 −5（默认绑定，可在键位设置中改）；另有 =/− 增减 1，Enter/空格 确定并开始，Esc 返回菜单；组卡界面卡牌焦点以金色描边高亮。',
    ],
  },
  {
    version: 'v0.7.1',
    date: '2026-08-16',
    title: '机制：牌库抽干不循环 · 双方出完即平局 · 新增投降与求和',
    items: [
      '卡牌出完了就是出完了：移除弃牌堆洗回牌库的循环抽牌，牌库抽干即止，不再摸牌、也没有疲劳 buff/debuff。',
      '平局判定：当双方「手牌与牌库皆空」且天平与场面连续一轮（A 回合开始快照）无变化——包括双方单位都只向天平平推、分数差永远拉不开的真·僵局——判平局。',
      '新增「投降」：认输即对方直接获胜（仅自己回合可发起，有二次确认）。',
      '新增「求和」：申请平局，每方一局仅可申请 1 次；对方可选择「接受（平局）」或「拒绝（继续）」。拒绝后对方仍可在其唯一一次机会内反申请。单机模式下 AI 会根据天平形势自动回应（落后/平局接受、领先拒绝）。',
      '无头仿真五阵营（PER=500，抽干机制下）：spread 2.9pt（≤10 达标），且对局平均回合数大幅缩短、稳定终止无死循环。',
    ],
  },
  {
    version: 'v0.7.0',
    date: '2026-08-16',
    title: '时砂新增机械 / 钟表 / 指针主题卡（同数量替换填充卡，规模与平衡不变）',
    items: [
      '新增 8 张机械/钟表/指针风格时砂卡：发条鼠（断尾·2/1）、齿轮蝇（飞行·1/2）、擒纵轮（2/2）、游丝（回复·1/3）、秒针（连击·2/1）、时针（重甲·2/3）、分针（尖刺·3/3）、黄铜傀儡（3/3）。主题覆盖发条、齿轮、擒纵、游丝、时钟三针（时/分/秒）、黄铜傀儡。',
      '采用「同数量替换」保持平衡：移除 8 张最通用的砂生物填充卡（时蜥/刻狐/刻雀/时鹡/砂蚁/砂蟀/时蛾/沙岩撞兽），新卡进默认牌组，牌库规模仍 22 张（23 张含 0 费砂砾×2），数值曲线与能量 1:1 镜像不变。',
      '无头仿真五阵营（PER=500）：在替换后重新跑，spread 仍 ≤5（详见提交说明），时砂强度未因新印记组合失稳。',
    ],
  },
  {
    version: 'v0.6.9',
    date: '2026-08-16',
    title: '纯数值平衡重调（仅改 atk/hp，不动机制/印记/费用）',
    items: [
      '思路：偏强阵营只能靠削其数值来压、偏弱阵营靠其对手被削后被间接抬升（单卡微调对本阵营胜率仅约 0.1pt，故采用「成批削强」而非加卡救弱）。',
      '削 blood（原 55.9% 最高）：stoat/beaver/raccoon 2/2→2/1、wolf 3/2→2/2、bullfrog/great_white/warthog 3/3→3/2、ferret/cougar/warg/otter 3/2·2/3→2/2、hound 3/4→3/3、viper_king 3/2→2/2、bear 5/4→4/3、rat_king 1/4→1/3、hedgehog 2/3→2/2、armored_badger 2/2→2/1。',
      '削 mox（原 52.0% 次高，全免费单位隐性过强）：panther/python/demon/griffin/soul_reaper/frost_assassin 2/2→2/1、manticore/chimera 3/2·2/3→2/2、basilisk 2/2→1/2、phoenix 3/3→3/2、golem 2/5→2/3、bone_hound 2/3→2/2。',
      '无头仿真五阵营（PER=500，12500 局）：blood 49.1% / mox 50.4% / energy 50.0% / sand 49.3% / bone 51.0%，spread 1.9pt（基线 9.1pt），五阵营全部落在 49–51%、均值≈50%，为历史最紧。配对矩阵离对角值由基线 75–125 收窄至 88–112。',
    ],
  },
  {
    version: 'v0.6.8',
    date: '2026-08-16',
    title: '机制调整：血肉可占献祭格 · 骸骨改为死亡掉落 · 时砂倒计时归位',
    items: [
      '血肉：打出有费血肉牌时，可把新单位直接放在「刚被献祭的格子」上（与其它阵营统一：放在刚腾出的那一列）。选好祭品且血肉够后，该列显示「取代此格 ▲」虚线提示。',
      '骸骨：资源计算改为「以任何方式死亡的卡牌数」——己方单位阵亡 / 0 费易碎生物攻击后碎裂 / 致死等，每只掉落 1 点骸骨（BONE_DEATH_GAIN=1）；同时去掉每回合无偿滴流，仅保留极轻的兜底累加（约 0.75/回合），避免与死亡经济叠加成洪流。死亡处新增「💀 +1🦴」骨片迸发特效 + 音效。',
      '时砂：剩余秒数资源统一显示在顶部资源条（与其它阵营召唤条件同位置）；顶栏「⏱」则统一为真实 20 秒回合倒计时（所有阵营一致）。修复了此前 UI 中时砂预算被真实计时器覆盖的 bug。',
      '无头仿真五阵营（PER=500）：blood 54.9% / bone 48.6% / energy 47.2% / mox 52.1% / sand 47.1%，spread 7.8pt（≤10），平衡达标。',
    ],
  },
  {
    version: 'v0.6.7',
    date: '2026-08-16',
    title: '每回合时限硬编码为 20 秒 · 菜单按钮加可见选中态',
    items: [
      '「每回合时限（PvP/PvE）」不再可调：移除关闭/10s/20s/30s/60s 选项按钮，统一硬编码为 20 秒（原选关闭/10s/30s/60s 的旧存档将被强制拉回 20 秒）。',
      '修复菜单中「AI 难度」「人机出牌速度」按钮没有任何可见选中态的 bug——现在选中的按钮会以金色高亮 + 描边发光显示，一眼可辨当前所选项。',
    ],
  },
  {
    version: 'v0.6.6',
    date: '2026-08-16',
    title: '组卡组支持多套保存（我的卡组）',
    items: [
      '组卡界面新增「我的卡组」管理条：可命名保存多套卡组，下拉切换读取、另存为、删除，全部存于本地（localStorage）跨局保留。',
      '「确定并开始」时会自动把当前卡组存入「我的卡组」（覆盖同名/同内容或新建），下次进组卡界面默认高亮上次的卡组。',
      '旧版「最后使用卡组」会自动迁移为「默认卡组」第一条，已有存档无缝兼容。',
    ],
  },
  {
    version: 'v0.6.5',
    date: '2026-08-16',
    title: '新阵营「时砂」——消耗剩余秒数召唤',
    items: [
      '新增第 5 阵营「时砂」：召唤方式 = 消耗「剩余秒数」，卡牌以「秒」为费，不可透支（剩余不足无法打出，例如剩 4 秒打不出 5 秒的牌）。',
      '秒能预算与能量阵营同构地爬升：每回合开始重置，首回合 0、之后每 2 个己方回合 +1、封顶 5（无无偿经济、无额外成长，全靠当回合秒数铺场）。',
      '配套 22 张时砂卡，单位数值曲线 1:1 镜像能量阵营（1 费×7 / 2 费×9 / 3 费×3 / 4 费×2 / 0 费×1），主题改为时钟/沙漏/流沙与时光生物，含飞行/毒触/尖刺/连击/厚甲/不死/回复/狂热等印记。',
      '平衡结果：无头仿真五阵营全交叉（每对位 300~500 局）显示时砂胜率约 47%，与能量（约 47%）同档，五阵营 spread 降至约 8pt（目标 ≤10），不再偏强或偏弱。',
      '出牌界面成本角标显示「N秒」；组卡/收藏/玩法说明/教程/对手 AI 均已接入该阵营。',
    ],
  },
  {
    version: 'v0.6.4',
    date: '2026-08-16',
    title: '人机出牌速度可调 · PvP/PvE 每回合出牌时限',
    items: [
      '新增「人机出牌速度」设置（菜单）：慢 / 正常 / 快 / 瞬发，控制对手（AI）出牌演示节奏。',
      '新增「每回合时限」设置（菜单，默认 20s，可关 / 10s / 20s / 30s / 60s）：PvP 与 PvE 每方每回合倒计时，时间到自动结束回合；剩余 ≤5s 时计时器变红脉动提醒。',
      '人机不思考、直接按顺序打牌：对手回合按设定速度逐步演示（瞬发即 0ms 一口气打出），不占用思考时间；计时器只对人类玩家的回合生效。',
      '教程模式不启用计时器，避免打扰学习；同屏双人 / 排位交接时计时器随当前行动方重置。',
    ],
  },
  {
    version: 'v0.6.3',
    date: '2026-08-16',
    title: '对手出牌分步演示（PvE 可看清）',
    items: [
      'AI（对手）出牌改为逐步演示：每出一张牌间隔约 0.78 秒（简单难度 0.56 秒），玩家能逐步看清对手的每一步操作，不再一瞬间全部打出。',
      '对手每打出一张牌，该单位会以金色脉冲高亮（ai-just），并在顶部状态栏显示「对手打出「卡名」」，配合召唤光柱演出，出牌动作一目了然。',
      '内部重构：AI 决策与执行分离为生成器（aiTurnPlan），无头平衡仿真仍走一次性接口（aiTakeTurn / runAITurn），行为完全不变。',
    ],
  },
  {
    version: 'v0.6.2',
    date: '2026-08-16',
    title: '战斗演出 · 卡面剪影 · 引导动画',
    items: [
      '战斗演出升级：召唤时从列中心冲出光能柱；单位死亡改为碎片四散的碎裂动画；血肉献祭时播放红色血光上涌的血祭特效（与献祭音效对齐）。',
      '打击反馈增强：连击（double_strike）触发金色「双击!」爆点与屏幕强震动；致死（death_touch）触发紫色「即死!」；尖刺反伤飘「反伤」提示；天平重击显示 ×2。',
      '卡面独特剪影：每张卡在共用基础造型之上，依据印记（飞行加翼、连击/高攻加角、尖刺加刺、厚甲加甲片、致死红眼、毒触毒滴、再生光环）与费用（高费加华丽尾）叠加差异化轮廓，并由卡牌 ID 决定轻微姿态倾斜，同造型的卡也各不相同。',
      '新手引导动画化：教程的「出牌」步指向手牌区、「结束回合」步指向对应按钮，目标元素金色脉冲高亮 + 动态箭头浮动引导；交互步遮罩背景更淡，保证目标清晰可见。',
    ],
  },
  {
    version: 'v0.6.1',
    date: '2026-08-16',
    title: '观感打磨与手感修正',
    items: [
      '修复手牌 Bug：移除了「所有手牌每次重渲染都重弹入场动画」的全局规则，改为仅新抽到的牌才播入场动画。此前每次选牌 / 切换回合整手牌都会反复跳一下，观感廉价。',
      '棋盘上敌方单位不再显示手型光标（不能点），仅己方可操作的手牌 / 献祭目标保持手型。',
      '轮到玩家出牌时，回合标签（轮到：xxx）改为金色呼吸高亮，强化「该你出牌了」的提示。',
      '新增非战斗加血反馈：regen 等导致的生命提升会在单位上方飘出绿色「+N♥」，与挨打时的红色「-N」飘字呼应。',
    ],
  },
  {
    version: 'v0.6.0',
    date: '2026-08-15',
    title: '键盘交互（战斗界面全键盘操作）',
    items: [
      '战斗界面新增完整键盘操作：数字 1-9 选中手牌；选中牌后按 1-4 或 Q/W/E/R 在对应列出牌（空列）或献祭（己方单位列）；方向键 ←→ 移动手牌 / 列光标；空格 / Enter 结束回合（无选牌时）或在列光标打出（有选牌时）；Esc 取消选牌 / 献祭。',
      '手牌左上角显示键盘序号角标，战场列号在选中牌时高亮为「出牌（金）/ 献祭（红）」目标，并新增底部键盘操作提示条，键位一目了然。',
      '鼠标点击操作完全保留，键盘与鼠标可任意混用。',
    ],
  },
  {
    version: 'v0.5.3',
    date: '2026-08-15',
    title: '在线联机 · 健壮性与可达性',
    items: [
      '线上联机（P2P）新增「信令自动降级」：若 PeerJS 信令服务不可用，自动切换到「邀请码」模式（纯 WebRTC + 公共 STUN，无需任何服务器），联网成功率大幅提升。',
      '本地联机（运行 node server.js 的权威转发）新增网络异常兜底：服务器未运行 / 房间无效时，给出清晰指引而非静默失败。',
      '主菜单新增「联机模式说明 / 服务器状态探测」：非本机部署时提示线上联机为点对点；本机部署时实时检测 server.js 是否在运行。',
    ],
  },
  {
    version: 'v0.5.2',
    date: '2026-08-15',
    title: '界面布局设置（可选紧凑模式）',
    items: [
      '新增「界面布局」开关（主菜单 🎚 按钮，设置里可调）：标准（默认）/ 紧凑。',
      '紧凑布局：选择模式菜单改为三列网格铺开；组卡界面改为「左侧阵营栏 + 右侧卡牌」真双栏（阵营栏吸顶，卡牌区独立滚动）。',
      '布局偏好随账号持久化，重新进入自动恢复；默认仍为标准布局。',
    ],
  },
  {
    version: 'v0.5.1',
    date: '2026-08-12',
    title: '排位赛 · 线上 P2P',
    items: [
      '排位赛新增「线上 P2P 对战」：双方各用自己设备与账号，房主创建房间、对方输入房间号/邀请码加入，WebRTC 直连（无需服务器）。',
      '双方段位各自独立结算——房主=玩家A、挑战者=玩家B，各自按胜负升降自己的段位，互不干扰。',
      '支持两种连接方式：一键房号（PeerJS 信令）与「邀请码」模式（原始 WebRTC + 公共 STUN，摆脱对信令服务器的依赖）。',
      '排位房主邀请链接使用 ?rjoin= 参数，对方打开即进入排位加入流程；同屏双人入口仍保留。',
    ],
  },
  {
    version: 'v0.5.0',
    date: '2026-08-12',
    title: '排位赛（PVP 段位）',
    items: [
      '新增「排位赛」模式，仅限 PVP（同屏双人对战），菜单新增入口。',
      '段位体系：共六阶（一阶最低 → 六阶最高），每阶分下 / 中 / 上三个小阶，共 18 个段位。',
      '胜 +30 晋级分、负 −30 晋级分；小阶内满 100 分晋级上一阶，归零则降级；封顶六阶·上、封底一阶·下。',
      '主菜单顶栏实时显示当前段位；排位赛界面含段位徽章、晋级进度条与排位战绩。',
    ],
  },
  {
    version: 'v0.4.0',
    date: '2026-08-11',
    title: '神话卡牌与付费货币',
    items: [
      '新增付费货币「魂晶」(💎)：充值获取，用于暗夜卡包、直购卡牌、兑换金币。',
      '新增「神话」稀有度——8 张高级卡牌（血肉巨人 / 吸血女王 / 巫妖之王 / 骨龙 / 欧米伽核心 / 风暴鹞 / 大法师 / 虚空幻影），仅可通过魂晶获取。',
      '神话卡牌拥有专属宇宙星云背景、金色光环与动画边框，强度略高于同费普通卡但有明确弱点。',
      '暗夜卡包新增 4% 神话掉率；直购商店神话卡定价 200 💎。',
      '手机端全面适配：5 个响应式断点 + 触屏优化。',
    ],
  },
  {
    version: 'v0.3.0',
    date: '2026-08-09',
    title: '内容扩展与更名',
    items: [
      '产品正式更名为「邪刻」。',
      '上线「每日新增卡牌」：现已加入 重甲獾 / 尖刺甲虫 / 冰晶刺客 三张新卡，之后每天持续扩充。',
      '新增本更新日志，记录每次重要改动。',
      '2026-08-09 每日新增：墓苔尸 / 自修机甲 / 石鳞卫',
      '2026-08-12 每日新增：刺猬 / 冢卫 / 霜灵',
      '2026-08-14 每日新增：豪猪 / 骨弓手 / 剧毒蜂',
      '2026-08-15 每日新增：水獭 / 齿轮犬 / 熔岩哨',
      '2026-08-30 每日新增：噬魂骨 / 回响机 / 苔绒精',
      '2026-08-31 每日新增（补跑 08-31~09-04）：穿山甲 / 食尸鬼 / 琥珀兽',
      '2026-09-01 每日新增（补跑）：巨鳄 / 蜂群机 / 荆棘藤',
      '2026-09-02 每日新增（补跑）：掘墓人 / 处决机 / 双生魔',
      '2026-09-03 每日新增（补跑）：灰獴 / 食腐兽 / 自爆机',
      '2026-09-04 每日新增（补跑）：鸢 / 恐惧骑士 / 赤瞳魔',
      '2026-09-05 每日新增：火蝾螈 / 哀号幽魂 / 电弧无人机',
    ],
  },
  {
    version: 'v0.2.0',
    date: '2026-08-02',
    title: '平衡重做与修复',
    items: [
      '重做血肉机制：移除无偿发放的血肉，献祭产出可在本回合内保留并滚雪球铺场，血肉阵营强度回归正常。',
      '修复 0 攻击力卡牌（如松鼠）误触发「-0」攻击特效与扑击动画的问题。',
      '四阵营胜率校准至约 50%（普通 / 困难难度胜率差 spread ≤ 10）。',
      '部署至公网，可分享链接直接试玩。',
    ],
  },
  {
    version: 'v0.1.0',
    date: '初版',
    title: '核心玩法上线',
    items: [
      '四阵营（血肉 / 骸骨 / 能量 / 魔石），各自独立的资源与召唤方式。',
      '单机对战 AI（简单 / 普通 / 困难）、本地联机、同屏双人。',
      '新手教程、卡牌图鉴、抽卡开包、自由组卡。',
      '像素风渲染、音效、天平胜负机制，以及多种印记（飞行 / 连击 / 毒触 / 尖刺 / 不死 / 断尾 / 头狼 / 易碎 等）。',
    ],
  },
];
